double x = 12.3;
double y = 4.56;
double z;

int main(void)
{
	z = x + y;
	return 0;
}
