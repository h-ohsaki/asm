double x1 = 1.23;
double x2 = 4.56;
double x3 = 7.8;

int main(void)
{
	double z = x1 + x2 - x3;
	return 0;
}
