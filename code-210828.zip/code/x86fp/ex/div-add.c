double x1 = 7.89;
double x2 = 1.23;
double x3 = 4.56;

int main(void)
{
	double z = x1 / (x2 + x3);
	return 0;
}
