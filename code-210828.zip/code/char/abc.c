char str[] = "ABC";
