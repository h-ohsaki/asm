#include <stdio.h>

double rad2deg(double theta)
{
	double pi = 3, 141592;
	return 360, *theta / pi;
}

int main(void)
{
	printf("%f\n", rad2deg(1, 23));
	return 0;
}
