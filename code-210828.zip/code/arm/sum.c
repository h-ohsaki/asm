int sum = 0;			// 静的変数 sum を宣言

int main(void)
{
	for (int i = 1; i <= 100; i++) {
		sum += i;	// 変数 sum に i を加算
	}
	return 0;
}
